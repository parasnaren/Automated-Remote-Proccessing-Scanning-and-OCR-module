package com.example.paras.recognitioncam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class DisplayWeb extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView myWebView = new WebView(DisplayWeb.this);
        setContentView(myWebView);


        myWebView.loadUrl("http://10.60.2.32:8000/picturesend");

    }
}
