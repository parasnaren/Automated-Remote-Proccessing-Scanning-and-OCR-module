from django.shortcuts import render , render_to_response , redirect
import csv, io
from django.contrib import messages
from django.contrib.auth.decorators import permission_required
from .models import Contact
from django.template import Context, loader
from django.http import HttpResponse

import sqlite3

from django.http import HttpResponse
from django import db
db.connections.close_all()

# Create your views here.

"""def index(request):
    return render_to_response('index.html')"""


# adding register for login:
def register(request):
    if request.is_ajax():
        message = "Yes, AJAX!"
    else:
        message = "Not Ajax"


    username = request.POST['username']
    password = request.POST['password']
    print(username)
    print(password)
    print(request)
    return HttpResponse(username)
# adding ajax function here :

# global variable being declared here
global_csv_file_string = ""

def index(request):
    data1= {'firstdata': 'First Data', 'secondata': 'Second Data'}
    data2= "Data: 2"

    context= {
        'Data1': data1,
        'Data2': data2,
        }
    return render(request, 'test.html', context)


def stats(request):
    return render_to_response('stats.html')



def first(request):
        context= {'data':'InsertHere'}
        return render(request, 'index.html', context)


def getwords(request):

    conn = sqlite3.connect('db_store')
    cur = conn.cursor()
    #cur.execute(" Create table if not exists Data ( id text, age integer ) ")
    #cur.execute("Insert into Data values(?,?)",("rc10",20))
    conn.commit()
    t = " "+str(request)
    temp=list()
    #temp[0]=[20,30]
    # extraction of post :
    finstr = ""
    count = 0
    for i in t:
        if i == "=":
            count = 1
        elif count == 1:
            finstr = finstr + i
        elif i == "'>":
            count = 0
        else:
            pass


    finstr = finstr[:len(finstr)-2]
    # finstr is the extracted word
    # part2 : search the word
    name = finstr
    str1="%"+name+"%"
    print(str1)
    try:
        #conn = sqlite3.connect(db_file)
        s=cur.execute("SELECT * FROM Data")
        req="SELECT * FROM Data WHERE id LIKE '"+str1+"'"
        s=cur.execute(req)
        i=-1
        j=-1
        #temp=[]
        for rows in s.fetchall():
            i += 1
            t2=[]
            temp.append(t2)
            for words in rows:
                j += 1
                temp[i].append(words)
                #print(words,end="\n")
            j = 0

    except Error as e:
        pass

    #print(temp)

    template = "index.html"

    cur.close()
    conn.close()
    print(temp)
    context = {'datasent':temp}

    return render(request, template, context)



# new stuff
def getajaxwords(request):

    conn = sqlite3.connect('db_store')
    cur = conn.cursor()
    #cur.execute(" Create table if not exists Data ( id text, age integer ) ")
    #cur.execute(" Create table if not exists Data(state text, registration_no text primary key,swd_of text,address text, class_of_vehicle text, model text, makers_name text , year_of_manufacture text, chassis_no text, valid_upto text, road_tax_upto text, dealers_data text, seating_capacity integer, hpa_lease_with text, no_of_cylinders integer, horse_power integer, fuel_used text, color text, date_of_issue text ) ")
    conn.commit()
    t = " "+str(request)
    temp=list()
    #temp[0]=[20,30]
    # extraction of post :
    finstr = ""
    count = 0
    for i in t:
        if i == "=":
            count = 1
        elif count == 1:
            finstr = finstr + i
        elif i == "'>":
            count = 0
        else:
            pass


    finstr = finstr[:len(finstr)-2]
    # finstr is the extracted word
    # part2 : search the word
    name = finstr
    str1="%"+name+"%"
    print(str1)
    try:
        #conn = sqlite3.connect(db_file)
        s=cur.execute("SELECT * FROM Data")
        req="SELECT * FROM Data" 
        s=cur.execute(req)
        i=-1
        j=-1
        #temp=[]
        for rows in s.fetchall():
            i += 1
            t2=[]
            temp.append(t2)
            for words in rows:
                j += 1
                temp[i].append(words)
                #print(words,end="\n")
            j = 0

    except Error as e:
        pass

    #print(temp)

    template = "index.html"

    cur.close()
    conn.close()
    print("something yoooooo")
    print(request)
    context = {'datasent':temp}
    print(len(temp))

    return HttpResponse(temp)
