from django.shortcuts import render , render_to_response , redirect
import csv, io
from django.contrib import messages
from django.contrib.auth.decorators import permission_required
from .models import Contact
from django.template import Context, loader
from django.http import HttpResponse

import sqlite3

from django.http import HttpResponse
from django import db



# Create your views here.

"""def index(request):
    return render_to_response('index.html')"""


# adding register for login:
def register(request):
    if request.is_ajax():
        message = "Yes, AJAX!"
    else:
        message = "Not Ajax"


    username = request.POST['username']
    password = request.POST['password']
    print(username)
    print(password)
    print(request)
    return HttpResponse(username)
# adding ajax function here :

# global variable being declared here
global_csv_file_string = ""

def index(request):
    data1= {'firstdata': 'First Data', 'secondata': 'Second Data'}
    data2= "Data: 2"

    context= {
        'Data1': data1,
        'Data2': data2,
        }
    return render(request, 'test.html', context)


def stats(request):
    return render_to_response('stats.html')



def first(request):
        context= {'data':'InsertHere'}
        return render(request, 'index.html', context)

#16:50
def getajaxwords(request):

    conn = sqlite3.connect('db_store')
    cur = conn.cursor()
    #cur.execute( " Create table if not exists RCData(state text, registration_no text primary key,serialno text,name text,swd_of text,address text, vehicle_class text, model text, makers_name text , year_of_manufacture text, chassis_no text,engine_no text,reg_date text, valid_date text, road_tax_upto text, seating_capacity text, no_of_cylinders text, horse_power text, fuel_used text, color text,purpose_code text, wheel_base text,cc text, weight text,body_type text,standing_capacity text) ")
    #cur.execute(" Create table if not exists Data(state text, registration_no text primary key,swd_of text,address text, class_of_vehicle text, model text, makers_name text , year_of_manufacture text, chassis_no text, valid_upto text, road_tax_upto text, dealers_data text, seating_capacity integer, hpa_lease_with text, no_of_cylinders integer, horse_power integer, fuel_used text, color text, date_of_issue text ) ")
    conn.commit()
    t = " "+str(request)
    temp=[]
    row_entry={'state': 'Karnataka',
               'registration_no':'RC10015',
               'serialno': '13456',
               'name':'XXX',
               'swd_of':'XXX',
               'address': 'Flat 300 Jayanagar, Bsk, asdfasdf, asfdasdf,',
               'vehicle_class' : 'LMVCAR',
               'model': 'car name',
               'makers_name':'Maruthi',    
               'year_of_manufacture':'2010',
               'chassis_no':'ASDF1291301',
               'engine_no':'ASDF129',
               'reg_date': '12/2/2000',
               'valid_date':'11/2/2020',
               'road_tax_upto':'2019',
               'seating_capacity':'5',
               'no_of_cylinders':'5',
               'horse_power':'756',
               'fuel_used':'Petrol',
               'color':'White',
               'purpose_code':'NEW',
               'wheel_base': '1234',
               'cc': '1598',
               'weight': 'null',
               'body_type': 'Saloon',
               'standing_capacity': 'null',
               }
    list_to_be_entered=list()
    for key in row_entry:
        list_to_be_entered.append(row_entry[key])
    t1=tuple(list_to_be_entered)

    #cur.execute("Insert into RCData values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",t1)
    conn.commit()
    

    #temp[0]=[20,30]
    # extraction of post :
    finstr = ""
    count = 0
    for i in t:
        if i == "=":
            count = 1
        elif count == 1:
            finstr = finstr + i
        elif i == "'>":
            count = 0
        else:
            pass


    finstr = finstr[:len(finstr)-2]
    # finstr is the extracted word
    # part2 : search the word
    name = finstr
    str1="%"+name+"%"
    print(str1)
    try:
        #conn = sqlite3.connect(db_file)
        s=cur.execute("SELECT * FROM RCData")
        req="SELECT * FROM RCData" 
        s=cur.execute(req)
        i=-1
        j=-1
        #temp=[]
        for rows in s.fetchall():
            i += 1
            t2=[]
            temp.append(t2)
            for words in rows:
                j += 1
                temp[i].append(words+"|")
                #print(words,end="\n")
            j = 0
            print(temp)
    except Error as e:
        pass

    print(temp)

    #template = "index.html"

    cur.close()
    conn.close()
    print("something yoooooo")
    print(request)
    #context = {'datasent':temp}
    #print(len(temp))

    return HttpResponse(temp)

	

	
	
# new stuff ->old
def getajaxwords1(request):

    conn = sqlite3.connect('db_store')
    cur = conn.cursor()
    #cur.execute(" Create table if not exists Data ( id text, age integer ) ")
    #cur.execute(" Create table if not exists Data(state text, registration_no text primary key,swd_of text,address text, class_of_vehicle text, model text, makers_name text , year_of_manufacture text, chassis_no text, valid_upto text, road_tax_upto text, dealers_data text, seating_capacity integer, hpa_lease_with text, no_of_cylinders integer, horse_power integer, fuel_used text, color text, date_of_issue text ) ")
    conn.commit()
    t = " "+str(request)
    temp=list()
    #temp[0]=[20,30]
    # extraction of post :
    finstr = ""
    count = 0
    for i in t:
        if i == "=":
            count = 1
        elif count == 1:
            finstr = finstr + i
        elif i == "'>":
            count = 0
        else:
            pass


    finstr = finstr[:len(finstr)-2]
    # finstr is the extracted word
    # part2 : search the word
    name = finstr
    str1="%"+name+"%"
    print(str1)
    try:
        #conn = sqlite3.connect(db_file)
        s=cur.execute("SELECT * FROM Data")
        req="SELECT * FROM Data" 
        s=cur.execute(req)
        i=-1
        j=-1
        #temp=[]
        for rows in s.fetchall():
            i += 1
            t2=[]
            temp.append(t2)
            for words in rows:
                j += 1
                temp[i].append(words)
                #print(words,end="\n")
            j = 0

    except Error as e:
        pass

    #print(temp)

    template = "index.html"

    cur.close()
    conn.close()
    print("something yoooooo")
    print(request)
    context = {'datasent':temp}
    print(len(temp))

    return HttpResponse(temp)



def extract_data(request):
	#Add Paras' CV2 code here 
    conn = sqlite3.connect('db_store')
    cur = conn.cursor()
    cur.execute( " Create table if not exists RCData(state text, registration_no text primary key,serialno text,name text,swd_of text,address text, vehicle_class text, model text, makers_name text , year_of_manufacture text, chassis_no text,engine_no text,reg_date text, valid_date text, road_tax_upto text, seating_capacity text, no_of_cylinders text, horse_power text, fuel_used text, color text,purpose_code text, wheel_base text,cc text, weight text,body_type text,standing_capacity text) ")
    #cur.execute(" Create table if not exists Data(state text, registration_no text primary key,swd_of text,address text, class_of_vehicle text, model text, makers_name text , year_of_manufacture text, chassis_no text, valid_upto text, road_tax_upto text, dealers_data text, seating_capacity integer, hpa_lease_with text, no_of_cylinders integer, horse_power integer, fuel_used text, color text, date_of_issue text ) ")
    conn.commit()
    t = " "+str(request)
    temp=[]
    row_entry={'state': 'Karnataka',
               'registration_no':'RC10999',
               'serialno': '13456',
               'name':'XXX',
               'swd_of':'XXX',
               'address': 'Flat 300 Jayanagar, Bsk, asdfasdf, asfdasdf,',
               'vehicle_class' : 'LMVCAR',
               'model': 'car name',
               'makers_name':'Maruthi',    
               'year_of_manufacture':'2010',
               'chassis_no':'ASDF1291301',
               'engine_no':'ASDF129',
               'reg_date': '12/2/2000',
               'valid_date':'11/2/2020',
               'road_tax_upto':'2019',
               'seating_capacity':'5',
               'no_of_cylinders':'5',
               'horse_power':'756',
               'fuel_used':'Petrol',
               'color':'White',
               'purpose_code':'NEW',
               'wheel_base': '1234',
               'cc': '1598',
               'weight': 'null',
               'body_type': 'Saloon',
               'standing_capacity': 'null',
               }
    list_to_be_entered=list()
    for key in row_entry:
        list_to_be_entered.append(row_entry[key])
    t1=tuple(list_to_be_entered)

    cur.execute("Insert into RCData values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",t1)
    conn.commit()
    print("Insertion successful")
    return HttpResponse('')